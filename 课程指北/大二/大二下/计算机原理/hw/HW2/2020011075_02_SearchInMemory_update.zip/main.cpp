/*************************************************************************
【文件名】                 main.cpp
【功能模块和目的】         检验SearchInMemory
【开发者及日期】           彭程 2022/3/13
【更改记录】               2022/6/28，对修改后的SearchInMemory重新进行了测试
*************************************************************************/
#include<stdio.h>
#include"2020011075_02_01_ SearchInMemory.hpp"
int main() {
	vector<int*> IntPtrList;
	vector<float*> FltPtrList;
	vector<double*> DblPtrList;
	int a = 99;
	int b = 98;
	int c = 99;
	float d = 99.1;
	float e = 99.6;
	float f = 98.9;
	double g= 99.1;
	double h = 99.6;
	double i = 98.6;
	void* sizebegin = malloc(sizeof(int) * 3 + sizeof(float) * 3 + sizeof(double) * 3);
	void* beginptr = sizebegin;
	memcpy((int*)sizebegin, &a, sizeof(int));
	memcpy((int*)sizebegin + 1, &b, sizeof(int));
	memcpy((int*)sizebegin + 2, &c, sizeof(int));
	memcpy((float*)sizebegin+3, &d, sizeof(float));
	memcpy((float*)sizebegin+4, &e, sizeof(float));
	memcpy((float*)sizebegin + 5, &f, sizeof(float));
	memcpy((double*)((float*)sizebegin + 6) , &g, sizeof(double));
	memcpy((double*)((float*)sizebegin + 6) + 1, &h, sizeof(double));
	memcpy((double*)((float*)sizebegin + 6) + 2, &i, sizeof(double));
	int value = 99;
	size_t size = 48;
	cout << SearchInMemory(value, beginptr, size, IntPtrList, FltPtrList, DblPtrList)<<endl;
	cout << "int" << endl;
	for (int i = 0; i < IntPtrList.size(); i++) {
		cout << IntPtrList[i] << endl;
	}
	cout << "float" << endl;
	for (int i = 0; i < FltPtrList.size(); i++) {
		cout << FltPtrList[i] << endl;
	}
	cout << "double" << endl;
	for (int i = 0; i < DblPtrList.size(); i++) {
		cout << DblPtrList[i] << endl;
	}
}
