/*************************************************************************
【文件名】                 2020011075_02_01_ SearchInMemory.hpp
【功能模块和目的】         声明SearchInMemory函数
【开发者及日期】           彭程 2022/3/13
【更改记录】               2022/6/28，根据范老师的讲解对于可能情况进行了完善
*************************************************************************/
#ifndef SEARCHINMEMORY_H    
#define SEARCHINMEMORY_H   

#include<vector>
#include<iostream>
using namespace std;
/*************************************************************************
【函数名称】      SearchInMemory（）
【函数功能】      在内存中查询待查找值并返回地址
【参数】          int Value,//从游戏显示中读到的数值
				          void* MemoryBegin,//指向游戏内存需搜索区域的指针，其值一定是8的整数倍
				          size_t SizeInByte,//游戏内存需搜索区域的字节数
				          vector<int*>& IntPtrList,//int型Value的地址
	                vector<float*>& FltPtrList,//float型Value的地址
	                vector<double*>& DblPtrList//double型Value的地址
【返回值】        bool型，当搜索结果为空时返回false，否则为true
【开发者及日期】  彭程 2022/3/13
*************************************************************************/
bool SearchInMemory(
	int Value,//从游戏显示中读到的数值
	void* MemoryBegin,//指向游戏内存需搜索区域的指针，其值一定是8的整数倍；
	size_t SizeInByte,//游戏内存需搜索区域的字节数
	vector<int*>& IntPtrList,//int型Value的地址
	vector<float*>& FltPtrList,//float型Value的地址
	vector<double*>& DblPtrList//double型Value的地址
);


#endif            


