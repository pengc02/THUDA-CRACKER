/*************************************************************************
【文件名】                 2020011075_02_01_ SearchInMemory.cpp
【功能模块和目的】         定义SearchInMemory函数
【开发者及日期】           彭程 2022/3/13
【更改记录】               2022/6/28，根据范老师的讲解对于可能情况进行了完善
*************************************************************************/
#include"2020011075_02_01_ SearchInMemory.hpp"

bool SearchInMemory(
	int Value,//从游戏显示中读到的数值
	void* MemoryBegin,//指向游戏内存需搜索区域的指针，其值一定是8的整数倍；
	size_t SizeInByte,//游戏内存需搜索区域的字节数
	vector<int*>& IntPtrList,//int型Value的地址
	vector<float*>& FltPtrList,//float型Value的地址
	vector<double*>& DblPtrList//double型Value的地址
) {
	int* m_int;
	m_int = (int*)MemoryBegin;
	float* m_float;
	m_float = (float*)MemoryBegin;
	double* m_double;
	m_double = (double*)MemoryBegin;

	int size = SizeInByte / 8 * 2;

	for (int i = 0; i < size; i++) {
		//来源于整数,直接比较即可
		if (*(m_int + i) == Value) {
			IntPtrList.push_back(m_int + i);
		}
		//来源于float的rouding
		if (Value >= 0 && *(m_float + i) >= Value && *(m_float + i) < Value + 1
			|| Value < 0 && *(m_float + i) > Value - 1 && *(m_float + i) <= Value) {
			FltPtrList.push_back(m_float + i);
		}
		//来源于float的格式化输出
		else if (Value % 2 == 0 && *(m_float + i) >= Value - 0.5 && *(m_float + i) <= Value + 0.5
			|| Value % 2 != 0 && *(m_float + i) > Value - 0.5 && *(m_float + i) < Value + 0.5) {
			FltPtrList.push_back(m_float + i);
		}

		if (i % 2 == 0) {//来源于double
			//来源于double的rouding
			if (Value >= 0 && *(m_double + i / 2) >= Value && *(m_double + i / 2) < Value + 1
				|| Value < 0 && *(m_double + i / 2) > Value - 1 && *(m_double + i / 2) <= Value) {
				DblPtrList.push_back(m_double + i / 2);
			}
			//来源于double的格式化输出
			else if (Value % 2 == 0 && *(m_double + i / 2) >= Value - 0.5 && *(m_double + i / 2) <= Value + 0.5
				|| Value % 2 != 0 && *(m_double + i / 2) > Value - 0.5 && *(m_double + i / 2) < Value + 0.5) {
				DblPtrList.push_back(m_double + i / 2);
			}
		}
	}
	if (SizeInByte % 8 >= 4) {
		if (*(m_int + size) == Value) {
			IntPtrList.push_back(m_int + size);
		}
		//来源于float的rouding
		if (Value >= 0 && *(m_float + size) >= Value && *(m_float + size) < Value + 1
			|| Value < 0 && *(m_float + size) > Value - 1 && *(m_float + size) <= Value) {
			FltPtrList.push_back(m_float + size);
		}
		//来源于float的格式化输出
		else if (Value % 2 == 0 && *(m_float + size) >= Value - 0.5 && *(m_float + size) <= Value + 0.5
			|| Value % 2 != 0 && *(m_float + size) > Value - 0.5 && *(m_float + size) < Value + 0.5) {
			FltPtrList.push_back(m_float + size);
		}
	}

	//返回值，当搜索结果为空时返回false，否则为true
	return (!IntPtrList.empty() || !FltPtrList.empty() || !DblPtrList.empty());

}