//
//  Othello.hpp
//  Othello
//
//  Created by 范静涛 on 2022/4/2.
//  Changes by 彭程 on 2022/4/5

/*************************************************************************
【头文件名称】       Othello.hpp
【头文件说明】       黑白棋游戏的基础类声明
    class ColorEnum      颜色类
    class DirEnum        方向类
    class RowNoEnum      行号类
    class ColNoEnum      列号类
    class OthBoard       棋盘类
*************************************************************************/


#ifndef Othello_hpp
#define Othello_hpp

#include<stdio.h>
#include<iostream>
#include<string.h>
using namespace std;
//Color: black, white, space(no piece)
class ColorEnum {
public:
    enum Type{
        B = 0, //Black
        W = 1, //White
        S = 2  //Space
    };
private:
    //This class is not instantiatable不可实例化
    virtual void NoInstance() = 0;
};
using Color = ColorEnum::Type;

//Directions for search
class DirEnum{
public:
    enum Type{
        LEFT       = 0,
        LEFT_UP    = 1,
        UP         = 2,
        RIGHT_UP   = 3,
        RIGHT      = 4,
        RIGHT_DOWN = 5,
        DOWN       = 6,
        LEFT_DOWN  = 7
    };
private:
    //This class is not instantiatable
    virtual void NoInstance() = 0;
};
using Direction = DirEnum::Type;

//Row Number for R1 to R8
class RowNoEnum{
public:
    enum Type{
        R1 = 0,
        R2 = 1,
        R3 = 2,
        R4 = 3,
        R5 = 4,
        R6 = 5,
        R7 = 6,
        R8 = 7
    };
private:
    //This class is not instantiatable
    virtual void NoInstance() = 0;
};
using RowNo = RowNoEnum::Type;

//Column number from A to H
class ColNoEnum{
public:
    enum Type{
        A = 0,
        B = 1,
        C = 2,
        D = 3,
        E = 4,
        F = 5,
        G = 6,
        H = 7
    };
private:
    //This class is not instantiatable
    virtual void NoInstance() = 0;
};
using ColNo = ColNoEnum::Type;

//Row and Col offsets for neighborhood in the board
using Neighborhood = struct {
    int RowOffset;
    int ColOffset;
};

//Class for Othello games
class OthBoard{
public:
    //Default Constructor
    OthBoard();
    //Copy Constructor
    OthBoard(const OthBoard& Source);
    //Operator Assignment
    OthBoard& operator=(const OthBoard& Source);
    //Virtual destructor
    virtual ~OthBoard();
    
    //........
    //........
    //........
    //...BW...
    //...WB...
    //........
    //........
    //........
    void Init();

    //Print currnet board with pieces
    void Print() const;
  
    //Get whether or not you can flip in a certain direction, without counting the number of flips
    bool AnyDrctnlFlips(RowNo Row, ColNo Col, Direction Dir, Color Side) const;
    
    //Get whether or not you can flip, without counting the number of flips
    bool AnyFlips(RowNo Row, ColNo Col, Color Side) const;

    //Get the number of pieces that can be flipped in one direction, when you put own piece into the specified position
    unsigned int CountDrctnlFlips(RowNo Row, ColNo Col, Direction Dir, Color Side) const;

    //Get the number of pieces that can be flipped, when you put own piece into the specified position
    unsigned int CountFlips(RowNo Row, ColNo Col, Color Side) const;
    
    //Flip and return counts
    unsigned int DoFlips(RowNo Row, ColNo Col, Color Side);

protected:
    //Board Size 8 by 8
    constexpr static const int  SIZE = 8;
    //char for print: black, white, space
    constexpr static const char STATUS[3]={'B','W',' '};
    //enum array for convert from int to row number
    constexpr static const RowNo ROWS[] = {RowNo::R1, RowNo::R2, RowNo::R3, RowNo::R4, RowNo::R5, RowNo::R6, RowNo::R7, RowNo::R8};
    //enum array for convert from int to column number
    constexpr static const ColNo COLS[] = {ColNo::A,  ColNo::B,  ColNo::C,  ColNo::D,  ColNo::E,  ColNo::F,  ColNo::G,  ColNo::H};
    //enum array for convert from int to search direction
    constexpr static const Direction DIRS[] = {Direction::LEFT, Direction::LEFT_UP, Direction::UP,Direction::RIGHT_UP, Direction::RIGHT, Direction::RIGHT_DOWN, Direction::DOWN, Direction::LEFT_DOWN};
    //array of row and column offsets for search by direction
    constexpr static const Neighborhood NBHS[8] = {
        {.RowOffset =  0, .ColOffset = -1},  //LEFT      
        {.RowOffset = -1, .ColOffset = -1},  //LEFT_UP   
        {.RowOffset = -1, .ColOffset =  0},  //UP        
        {.RowOffset = -1, .ColOffset =  1},  //RIGHT_UP  
        {.RowOffset =  0, .ColOffset =  1},  //RIGHT     
        {.RowOffset =  1, .ColOffset =  1},  //RIGHT_DOWN
        {.RowOffset =  1, .ColOffset =  0},  //DOWN      
        {.RowOffset =  1, .ColOffset = -1}   //LEFT_DOWN 
    };
    static int GetCurrentRow(RowNo RowBase, Direction Dir, int Step);
    static int GetCurrentCol(ColNo ColBase, Direction Dir, int Step);
private:
    //default board
    //........
    //........
    //........
    //...BW...
    //...WB...
    //........
    //........
    //........
    static const char DEFAULT_BOARD[SIZE][SIZE];
    char Board[SIZE][SIZE];
};
// const char OthBoard::DEFAULT_BOARD[SIZE][SIZE] = {
//     //A         B         C         D         E         F         G         H
//      {Color::S, Color::S, Color::S, Color::S, Color::S, Color::S, Color::S, Color::S},  //1
//      {Color::S, Color::S, Color::S, Color::S, Color::S, Color::S, Color::S, Color::S},  //2
//      {Color::S, Color::S, Color::S, Color::S, Color::S, Color::S, Color::S, Color::S},  //3
//      {Color::S, Color::S, Color::S, Color::B, Color::W, Color::S, Color::S, Color::S},  //4
//      {Color::S, Color::S, Color::S, Color::W, Color::B, Color::S, Color::S, Color::S},  //5
//      {Color::S, Color::S, Color::S, Color::S, Color::S, Color::S, Color::S, Color::S},  //6
//      {Color::S, Color::S, Color::S, Color::S, Color::S, Color::S, Color::S, Color::S},  //7
//      {Color::S, Color::S, Color::S, Color::S, Color::S, Color::S, Color::S, Color::S}   //8
// };

// OthBoard::OthBoard(){
//     Init();
// }

// OthBoard::OthBoard(const OthBoard& Source){//内存别名问题优化
//     //copy
//     /*for (unsigned int Row = 0; Row < SIZE; Row++) {
//         for (unsigned int Col = 0; Col < SIZE; Col++) {
//             Board[Row][Col] = Source.Board[Row][Col];
//         }
//     }*/
//     memcpy(Board, Source.Board, SIZE * SIZE);//not overlap
// }

// OthBoard& OthBoard::operator=(const OthBoard& Source){//内存别名问题优化
//     if (this != &Source) {
//         //copy
//         /*for (unsigned int Row = 0; Row < SIZE; Row++) {
//             for (unsigned int Col = 0; Col < SIZE; Col++) {
//                 Board[Row][Col] = Source.Board[Row][Col];
//             }
//         }*/
//         memcpy(Board, Source.Board, SIZE * SIZE);//not overlap
//     }
//     return *this;
// }

// OthBoard::~OthBoard(){
// }

// void OthBoard::Init(){//内存别名问题优化
//     //copy from default board
//     /*for (unsigned int Row = 0; Row < SIZE; Row++) {
//         for (unsigned int Col = 0; Col < SIZE; Col++) {
//             Board[Row][Col] = DEFAULT_BOARD[Row][Col];
//         }
//     }*/
//     memcpy(Board, DEFAULT_BOARD, SIZE * SIZE);//not overlap
// }

// void OthBoard::Print() const{
//     cout << "  A B C D E F G H\n";
//     for (unsigned int Row = 0; Row < SIZE; Row++) {
//         cout << " +-+-+-+-+-+-+-+-+\n" << Row + 1 << '|' ;
//         for (unsigned int Col = 0; Col < SIZE; Col++) {
//             cout << STATUS[Board[Row][Col]] << '|';
//         }
//         cout << '\n';
//     }
//     cout << " +-+-+-+-+-+-+-+-+\n" << endl;
// }

// inline int OthBoard::GetCurrentRow(RowNo RowBase, Direction Dir, int Step) {//过程调用问题优化
//     return RowBase + NBHS[Dir].RowOffset * Step;
// }

// inline int OthBoard::GetCurrentCol(ColNo ColBase, Direction Dir, int Step) {//过程调用问题优化
//     return ColBase + NBHS[Dir].ColOffset * Step;
// }

// //Get whether or not you can flip in a certain direction, without counting the number of flips
// bool OthBoard::AnyDrctnlFlips(RowNo Row, ColNo Col, Direction Dir, Color Side) const{//功能比CountDrctnlFlips弱，将输出直接调用CountDrctnlFlips
//     //char OwnSide = Side;
//     //char OppSide = 1 - OwnSide;
//     //unsigned int FlipCount  = 0;
//     //
//     ////only can put a piece into a space
//     //if (Board[Row][Col] != Color::S) {
//     //    return false;
//     //}
//     //
//     ////search for a continued oppside serial
//     //int Step = 1;
//     //while (GetCurrentRow(Row, Dir, Step) < SIZE //先判断位置后颜色，绝对不能反，否则可能越界
//     //    && GetCurrentCol(Col, Dir, Step) < SIZE
//     //    && Board[GetCurrentRow(Row, Dir, Step)][GetCurrentCol(Col, Dir, Step)] == OppSide){
//     //    //add one oppside count
//     //    FlipCount++;
//     //    //to search next position
//     //    Step++;
//     //}//end while
//     //
//     ////afer an oppside serial, is an own side piece
//     //if (   GetCurrentRow(Row, Dir, Step) < SIZE //先判断位置后颜色，绝对不能反，否则可能越界
//     //    && GetCurrentCol(Col, Dir, Step) < SIZE
//     //    && Board[GetCurrentRow(Row, Dir, Step)][GetCurrentCol(Col, Dir, Step)] == OwnSide){
//     //    return true;
//     //}
//     //else {
//     //    return false;
//     //}
//     return CountDrctnlFlips(Row, Col, Dir, Side);
// }
// //Get the number of pieces that can be flipped in a certain direction, when you put own piece into the specified position
// unsigned int OthBoard::CountDrctnlFlips(RowNo Row, ColNo Col, Direction Dir, Color Side) const{//判断次数优化
//     char OwnSide = Side;
//     char OppSide = 1 - OwnSide;
//     unsigned int FlipCount  = 0;
    
//     //only can put a piece into a space
//     if (Board[Row][Col] != Color::S) {
//         return FlipCount;
//     }
    
//     //search for a continued oppside serial
//     int Step = 1;
//     while (GetCurrentRow(Row, Dir, Step) < SIZE //先判断位置后颜色，绝对不能反，否则可能越界
//         && GetCurrentCol(Col, Dir, Step) < SIZE){
//         if (Board[GetCurrentRow(Row, Dir, Step)][GetCurrentCol(Col, Dir, Step)] == OppSide) {
//             //add one oppside count
//             FlipCount++;
//             //add step to search next position
//             Step++;
//         }
//         else if (Board[GetCurrentRow(Row, Dir, Step)][GetCurrentCol(Col, Dir, Step)] == OwnSide)
//             return FlipCount;
//         else return 0;
//     }//end while
//     return 0;
//     ////afer an oppside serial, is an own side piece
//     //if (   GetCurrentRow(Row, Dir, Step) < SIZE //先判断位置后颜色，绝对不能反，否则可能越界
//     //    && GetCurrentCol(Col, Dir, Step) < SIZE
//     //    && Board[GetCurrentRow(Row, Dir, Step)][GetCurrentCol(Col, Dir, Step)] == OwnSide){
//     //    return FlipCount;
//     //}
//     //else {
//     //    return 0;
//     //}
// }
// //Get whether or not you can flip, without counting the number of flips
// bool OthBoard::AnyFlips(RowNo Row, ColNo Col, Color Side) const{//运算简化
//     unsigned int TotalFlipCount = 0;
//     for (auto e : DIRS) {
//         TotalFlipCount += CountDrctnlFlips(Row, Col, e, Side);
//     }
//     //if (TotalFlipCount > 0) {
//     //    return true;
//     //}
//     //else {
//     //    return false;
//     //}
//     return TotalFlipCount;
// }

// //Get the number of pieces that can be flipped, when you put own piece into the specified position
// unsigned int OthBoard::CountFlips(RowNo Row, ColNo Col, Color Side) const{//运算简化
//     unsigned int TotalFlipCount = 0;
//     for (auto e : DIRS) {
//         TotalFlipCount += CountDrctnlFlips(Row, Col, e, Side);
//     }
//     /*if (TotalFlipCount > 0) {
//         return TotalFlipCount;
//     }
//     else {
//         return 0;
//     }*/
//     return TotalFlipCount;
// }

// //Flip and return counts
// unsigned int OthBoard::DoFlips(RowNo Row, ColNo Col, Color Side){
//     unsigned int TotalFlipCount = 0;
//     //Flip to each direction
//     for (auto e : DIRS) {
//         //flip count of this direction
//         unsigned int FlipCount = CountDrctnlFlips(Row, Col, e, Side);
//         TotalFlipCount += FlipCount;
//         for (int Step = 1; Step <= FlipCount; Step++) {
//             Board[GetCurrentRow(Row, e, Step)][GetCurrentCol(Col, e, Step)] = Side;
//         }
//     }
//     if (TotalFlipCount > 0) {
//         Board[Row][Col] = Side;
//         return TotalFlipCount;
//     }
//     else {
//         return 0;
//     }
// }
#endif /* Othello_hpp */
